package week1;

import java.util.Scanner;

public class Homework {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("학번을 입력해주세요 : ");
        int s_num = sc.nextInt();

        sc.nextLine();
        System.out.print("이름을 입력해주세요 : ");
        String s_name = sc.nextLine();

        System.out.print("전화번호를 입력해주세요 : ");
        String s_phone = sc.nextLine();
        System.out.println();

        System.out.println("학번 : " +s_num);
        System.out.println("이름 : " +s_name);
        System.out.println("전화번호 : " +s_phone);
    }
}
