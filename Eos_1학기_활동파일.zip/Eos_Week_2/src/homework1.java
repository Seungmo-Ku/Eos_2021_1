public class homework1 {
    public static void main(String[] args) {
        int fir = 1, sec = 1;
        for (fir = 1; fir <= 9; fir ++) {
            for (sec = 1; sec <= 9; sec ++) {
                System.out.println(fir + " * " + sec + "= " +(fir*sec));
            }
        }
    }
}
