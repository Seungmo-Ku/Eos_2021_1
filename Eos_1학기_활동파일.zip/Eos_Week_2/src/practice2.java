import java.util.Scanner;

public class practice2 {
    public static int sumDigits (int integer) {
      //  System.out.println(integer);
        int sum = 0;
        while(integer > 0) {
            sum += integer%10;
            integer /= 10;

        }

        return sum;
    }
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);
        int integer = num.nextInt ();
       // System.out.println(integer / 10);
        int sum = sumDigits (integer);
        System.out.println(sum);
    }
}
