public class homework1_2 {
    public static void main(String[] args) {
        int fir = 1, sec = 1;
        while (fir <= 9) {
            while (sec <= 9) {
                System.out.println(fir + " * " + sec + "= " +(fir*sec));
                sec ++;
            }
            sec = 1;
            fir ++;
        }
    }
}
