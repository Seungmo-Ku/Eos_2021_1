public class practice1 {
    public static class Hero {
        String name;
        int hp = 0, speed = 0, damage = 0;

        Hero (String name, int hp, int speed, int damage) {
            this.name = name;
            this.hp = hp;
            this.speed = speed;
            this.damage = damage;
            System.out.println(name+"이(가) 생성되었습니다.");
        }
        String getDetailInfo() {
           return "이름 : "+name+ "\nHP : "+hp+ "\nspeed : "+speed+"\ndamage : "+damage;
        }
        void move() {
            System.out.println(name+"(이)가 "+speed+"의 속도로 이동합니다.");
        }
        void eSkill() {
            System.out.println(name+"(이)가 스킬을 사용했습니다.");
        }
        void attack(Hero enemy) {
            int temp = enemy.hp;
            enemy.hp -= damage;
            System.out.println(name+"(이)가 "+enemy.name+"을(를) 공격헤서 체력을 "+temp+"에서 "+enemy.hp+"(으)로 깎았습니다.");
        }
    }
    public static class Hanzo extends Hero {
        Hanzo() {
            super("Hanzo", 100, 50, 70);
        }
        @Override
        void eSkill() {
            System.out.println(name+"(이)가 eSkill인 갈래화살을 사용했습니다.");
        }
    }
    public static class Lucio extends Hero {
        Lucio () {
            super("Lucio", 80, 100, 40);
        }
        @Override
        void eSkill() {
                System.out.println(name+"(이)가 eSkill인 치유 증폭을 사용했습니다.");
            }
    }
    public static void main(String[] args) {
        Hanzo hanzo = new Hanzo();
        Hero lucio = new Lucio();

        hanzo.move();
        hanzo.eSkill();
        System.out.println(hanzo.getDetailInfo());

        lucio.move();
        lucio.eSkill();
        System.out.println(lucio.getDetailInfo());

        hanzo.attack(lucio);
        lucio.attack(hanzo);

        System.out.println(hanzo.getDetailInfo());
        System.out.println(lucio.getDetailInfo());

    }
}
