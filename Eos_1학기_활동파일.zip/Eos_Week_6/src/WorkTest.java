interface BurgerCook {
    void makeBurger();
    void makeSalad();
}
class HotelCook implements BurgerCook{
    public void makeBurger() {
        System.out.println("호텔급 햄버거 만듦");
    }
    public void makeSalad() {
        System.out.println("호텔급 샐러드 만듦");
    }
}
class PartTimer implements BurgerCook{
    public void makeBurger() {
        System.out.println("아르바이트급 햄버거 만듦");
    }
    public void makeSalad() {
        System.out.println("아르바이트급 샐러드 만듦");
    }
}
class BurgerClerk {
    void orderBurger (BurgerCook cook) {
        System.out.println("주방에 햄버거를 주문합니다.");
        cook.makeBurger();
    }
    void orderSalad (BurgerCook cook) {
        System.out.println("주방에 샐러드를 주문합니다.");
        cook.makeSalad();
    }
}
public class WorkTest {
    public static void main(String[] args) {
        BurgerCook hcook = new HotelCook();
        BurgerCook pcook = new PartTimer();
        BurgerClerk bk = new BurgerClerk();

        System.out.println("호텔식 햄버거 주문요청 들어옴.");
        bk.orderBurger(hcook);

        System.out.println("알바식 샐러드 주문요청 들어옴.");
        bk.orderSalad(pcook);

        System.out.println("알바식 햄버거 주문요청 들어옴.");
        bk.orderBurger(pcook);

        System.out.println("호텔식 샐러드 주문요청 들어옴.");
        bk.orderSalad(hcook);
    }
}
