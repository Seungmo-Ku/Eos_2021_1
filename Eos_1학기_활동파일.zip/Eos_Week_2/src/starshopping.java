 public class starshopping {
    public static void main(String[] args) {

        int a, b;
        // 1번

        for (a = 1; a <= 5; a ++) {
            for (b = 1; b <= a; b ++)
                System.out.print("*");
            System.out.println();
        }

        System.out.println();
        System.out.println();

        //2번
        for (a = 5; a >= 1; a --) {
            for (b = 1; b <= a; b ++)
                System.out.print("*");
            System.out.println();
        }

        System.out.println();
        System.out.println();

        //3번

        for (a = 1; a <= 5; a ++) {
            for (b = a; b <= 4; b ++)
                System.out.print(" ");
            for (b = 1; b <= a; b ++)
                System.out.print("*");

            System.out.println();
        }

        System.out.println();
        System.out.println();

        //4번
        for (a = 5; a >= 1; a --) {
            for (b = a; b <= 4; b ++)
                System.out.print(" ");
            for (b = 1; b <= a; b ++)
                System.out.print("*");

            System.out.println();
        }

        System.out.println();
        System.out.println();

        //5번

        for (a = 1; a <= 5; a ++) {
            for (b = a; b <= 4; b ++)
                System.out.print(" ");
            for (b = 1; b <= (2*a-1); b ++)
                System.out.print("*");
            System.out.println();
        }


        System.out.println();
        System.out.println();

        //6번
        for (a = 5; a >= 1; a --) {
            for (b = 5; b > a; b --)
                System.out.print(" ");
            for (b = 1; b <= (2*a-1); b ++)
                System.out.print("*");
            System.out.println();
        }

        System.out.println();
        System.out.println();

        //7번
        for (a = 1; a <= 5; a ++) {
            for (b = a; b <= 4; b ++)
                System.out.print(" ");
            for (b = 1; b <= (2*a-1); b ++)
                System.out.print("*");
            System.out.println();
        }
        for (a = 4; a >= 1; a --) {
            for (b = 4; b >= a; b --)
                System.out.print(" ");
            for (b = 1; b <= (2*a-1); b ++)
                System.out.print("*");
            System.out.println();
        }

        System.out.println();
        System.out.println();

        //8번
        for (a = 5; a >= 1; a --) {
            for (b = 5; b > a; b --)
                System.out.print(" ");
            for (b = 1; b <= (2*a-1); b ++)
                System.out.print("*");
            System.out.println();
        }
        for (a = 2; a <= 5; a ++) {
            for (b = a; b <= 4; b ++)
                System.out.print(" ");
            for (b = 1; b <= (2*a-1); b ++)
                System.out.print("*");
            System.out.println();
        }

        System.out.println();
        System.out.println();

        //9번
        for (a = 1; a <= 4; a ++) {
            for (b = 4; b >= a; b --)
                System.out.print("*");
            for (b = 1; b <= a; b ++)
                System.out.print(" ");
            for (b = 4; b >=a; b --)
                System.out.print("*");
            System.out.println();
        }
        System.out.println();
        for (a = 1; a <= 4; a ++) {
            for (b = 1; b <= a; b ++)
                System.out.print("*");
            for (b = 4; b >= a; b --)
                System.out.print(" ");
            for (b = 1; b <= a; b ++)
                System.out.print("*");
            System.out.println();
        }

        System.out.println();
        System.out.println();

        //10번

        for (a = 1; a <= 4; a ++) {
            for (b = 1; b <= a; b ++)
                System.out.print("*");
            for (b = 4; b >= a; b --)
                System.out.print(" ");
            for (b = 1; b <= a; b ++)
                System.out.print("*");
            System.out.println();
        }
        for (a = 1; a <= 3; a ++) {
            for (b = 3; b >= a; b --)
                System.out.print("*");
            for (b = 1; b <= a+1; b ++)
                System.out.print(" ");
            for (b = 3; b >= a; b --)
                System.out.print("*");

            System.out.println();
        }

    }
}
