public class week2 {
    public static void main(String[] args) {
        //parameter 매개변수
        //argument 인자

    }
}
