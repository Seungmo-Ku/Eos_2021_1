import java.util.Scanner;

public class homework2 {
    public static int sumDigitsByStr(int num) {
        String strN = "";
        strN = Integer.toString(num);//문자열로 변환
        int i;
        int sum = 0;
        for (i = 0; i <strN.length(); i ++) { //한자리씩 잘라서 정수로 변환해서 sum값에다가 더해줌
            sum += Integer.parseInt(strN.substring(i,i+1));
        }
        return sum;
    }

    public static void main(String[] args) {
        int numS;
        Scanner sc = new Scanner(System.in);
        numS = sc.nextInt();
        System.out.println(sumDigitsByStr(numS));
    }
}
