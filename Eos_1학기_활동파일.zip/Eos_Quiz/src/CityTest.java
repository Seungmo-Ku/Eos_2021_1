public class CityTest {
    public static void main(String[] args) {
        City Seoul = new City ("Seoul", 23, 45);
        City Paris = new City ("Paris", 123, 41);
        City Racoon_City = new City ("Racooon City");
        City Mega_City = new City ("Mega City");

        System.out.println(Seoul.toString());
        System.out.println(Paris.toString());
        System.out.println(Racoon_City.toString());
        System.out.println(Mega_City.toString());


        System.out.println(Seoul.getName() + "-" + Paris.getName() + " : " + City.distance(Seoul, Paris));
        System.out.println(Seoul.getName() + "-" + Racoon_City.getName() + " : " + City.distance(Seoul, Racoon_City));
        System.out.println(Paris.getName() + "-" + Mega_City.getName() + " : " + City.distance(Paris, Mega_City));
    }
}
