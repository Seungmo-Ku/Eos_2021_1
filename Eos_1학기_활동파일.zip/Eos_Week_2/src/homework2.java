public class homework2 {
    public static int payAmount (int time) {
        int price = 0;
        if (time <10) price = 0;
        else if (time >= 10 && time <= 30) price = 500;
        else {
            int time2 = (time - 30);
            price = 500;
            if (time2 < 10)
                price += 500;
            else
                price += (time2 / 10) * 500;
        }
        return price;
    }
    public static void main(String[] args) {
        int[] parkT = {5, 10, 12, 35, 60, 100, 300};
        for (int calcu: parkT) {
            int price = payAmount (calcu);
            System.out.println(price);
        }
    }
}
