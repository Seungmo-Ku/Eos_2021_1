package week1;

import java.util.Scanner;

public class Study2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

         float radius = sc.nextFloat();
         System.out.println("반지름이 "+radius+"인 원의 넓이는 "+radius*radius*3.14+"입니다.");
    }
}
