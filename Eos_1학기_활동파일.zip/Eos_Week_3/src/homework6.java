public class homework6 {
    public static class Student {
        void ShowInfo () {
            System.out.println("Student : study");
        }
    }
    public static class CSStudent extends Student {
        @Override
        void ShowInfo () {
            super.ShowInfo();
            System.out.println("CSStudent : study Coding");
        }
    }
    public static class KorStudent extends Student {
        @Override
        void ShowInfo () {
            System.out.println("KorStudent : study Korean");
        }
    }
    public static class EngStudent extends Student {
        @Override
        void ShowInfo () {
            System.out.println("EngStudent : study English");
        }
    }
    public static class GraduateStudent extends Student {
        @Override
        void ShowInfo () {
            System.out.println("GraduateStudent : get a job");
        }
    }
    public static void main(String[] args) {
        Student s1 = new CSStudent();
        Student s2 = new KorStudent();
        Student s3 = new EngStudent();
        Student s4 = new GraduateStudent();
        s1.ShowInfo();
        s2.ShowInfo();
        s3.ShowInfo();
        s4.ShowInfo();

    }
}
