interface Healer {
    void healingAura();
    void holyArmor();
}
interface Sorcerer {
    void fireArmor();
    void thunderBlade();
}
interface Tanker {
    void increaseArmor();
    void increaseHp();
}
class Knight implements Tanker {
    String Name;
    int Hp, Armor;
    Knight (String Name, int Hp, int Armor) {
        this.Name = Name;
        this.Armor = Armor;
        this.Hp = Hp;
    }
    public void increaseArmor() {
        System.out.println("["+Name+"] increaseArmor() 시전!");
        System.out.println("아머가 +5 증가합니다.");
        Armor += 5;
    }
    public void increaseHp () {
        System.out.println("["+Name+"] increaseHp() 시전!");
        System.out.println("체력이 +100 증가합니다.");
        Hp += 100;
    }
}
class HolyKnight extends Knight implements Healer {
    HolyKnight(String Name, int Hp, int Armor) {
        super(Name, Hp, Armor);
    }
    public void healingAura() {
        System.out.println("["+Name+"] healingAura() 시전!");
        System.out.println("초당 체력회복이 +10 증가합니다.");
    }
    public void holyArmor() {
        System.out.println("["+Name+"] holyArmor() 시전!");
        System.out.println("데미지를 -10 덜 받습니다.");
    }
}
class MagicKnight extends Knight implements Sorcerer {
    MagicKnight(String Name, int Hp, int Armor) {
        super(Name, Hp, Armor);

    }
    public void fireArmor() {
        System.out.println("["+Name+"] fireArmor() 시전!");
        System.out.println("주변 적에게 초당 +10의 데미지를 줍니다.");
    }
    public void thunderBlade() {
        System.out.println("["+Name+"] thunderBlade() 시전!");
        System.out.println("매 공격시 +10의 추가 데미지를 줍니다.");
    }
}
public class rpgGame {
    public static void main(String[] args) {
        Knight uther = new HolyKnight("우서", 200, 10);
        Knight arthas = new MagicKnight("아서스", 150, 8);

        uther.increaseHp();
        uther.increaseArmor();

        HolyKnight holyUther = (HolyKnight) uther;
        System.out.println(holyUther.Hp);
        holyUther.healingAura();
        holyUther.holyArmor();

        arthas.increaseHp();
        arthas.increaseArmor();

        MagicKnight magicArthas = (MagicKnight) arthas;
        magicArthas.fireArmor();
        magicArthas.thunderBlade();
    }
}
