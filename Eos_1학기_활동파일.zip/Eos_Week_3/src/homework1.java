public class homework1 {
    static class Developer {
        String name;
        int year, salary, stat;
        Developer (String name, int year) {
            this.name = name;
            this.year = year;
            if (year <3)
                this.stat = 2800;
            else if (year <7)
                this.stat = 3500;
            else if (year >=7)
                this.stat = 4500;

            this.salary = this.stat + 100 * year;
        }

    }
    public static void main(String[] args) {
        Developer d1 = new Developer("박근원", 2);
        Developer d2 = new Developer("김희진", 5);
        Developer d3 = new Developer("박현준", 9);

        System.out.println(d1.name + "의 연봉은 " + d1.salary +"만원입니다.");
        System.out.println(d2.name + "의 연봉은 " + d2.salary +"만원입니다.");
        System.out.println(d3.name + "의 연봉은 " + d3.salary +"만원입니다.");
    }
}
