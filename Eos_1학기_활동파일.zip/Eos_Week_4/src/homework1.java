public class homework1 {
    public static void main(String[] args) {
        int[] lottoN = {0, 0, 0, 0, 0, 0, 0};
        int i, j;
        //(int)(Math.random()*44 + 1)
        for (i=0; i<7; i++) {
            lottoN[i] = (int)(Math.random()*44+1);
            //해당 인덱스에 랜덤으로 로또 번호 생성
            for (j=0; j<i; j++) { //i-1번째까지의 수와 i번째를 비교
                if (lottoN[i] == lottoN[j]){
                    i --; //i를 하나 빼서 겹치는 수를 다시 랜덤으로 할당
                    break;
                }
            }
        }
        System.out.println("=== 인생은 역시 한방! 로또 번호 자동생성기 ===");
        for (i=0; i<6; i++) {
            System.out.print(lottoN[i] + "     ");
        }
        System.out.println();
        System.out.println("실망하지 마세요. 보너스 번호가 있으니까요!");
        System.out.println("보너스 번호 : "+lottoN[6]);
    }
}
