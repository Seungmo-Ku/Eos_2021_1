package week1;

public class Study1 {
    public static void main(String[] args) {
        String str1 = "Hello", str2 = "World";

        System.out.println(str1.length());
        System.out.println(str1 + " " + str2);
        System.out.println(str1.substring(0, 4));
        System.out.println(str2.toUpperCase());
    }
}
