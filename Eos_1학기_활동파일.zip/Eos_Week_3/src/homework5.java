public class homework5 {
    public static class Currency {
        String name;
        double unit;
        Currency (double unit, String name) {
            this.unit = unit;
            this.name = name;
        }

    }
    public static class KRW extends Currency {
        KRW (double unit, String name) {
            super (unit, name);
        }
        @Override
        public String toString() {
            return "KRW : " +unit + " " + name;
        }
    }
    public static class USD extends Currency {
        USD (double unit, String name) {
            super (unit, name);
        }
        @Override
        public String toString() {
            return "USD : " +unit + " " + name;
        }
    }
    public static class EUR extends Currency {
        EUR (double unit, String name) {
            super (unit, name);
        }
        @Override
        public String toString() {
            return "EUR : " +unit + " " + name;
        }
    }
    public static class JPY extends Currency {
        JPY (double unit, String name) {
            super (unit, name);
        }
        @Override
        public String toString() {
            return "JPY : " +unit + " " + name;
        }
    }
    public static void main(String[] args) {
        KRW krw = new KRW(1500, "원");
        USD usd = new USD(100.5, "달러");
        EUR eur = new EUR(260.87, "유로");
        JPY jpy = new JPY(1400, "엔");

        Currency[] currencies = {krw, usd, eur, jpy};

        for (Currency c : currencies) {
            System.out.println(c.toString());
        }
    }
}
