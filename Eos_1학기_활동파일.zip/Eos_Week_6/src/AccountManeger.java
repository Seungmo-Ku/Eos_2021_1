import java.util.Scanner;

interface interface_account {
    void deposit(int money);
    void withdraw(int money);
    void showBalance();

}
class Account implements interface_account {
    private String accountNo;
    private int balance = 0;
    Account(String accountNo) {
        this.accountNo = accountNo;
    }

    public void deposit(int money) {
        balance += money;
    }

    public void withdraw(int money) {
        if (money > balance)
            System.out.println("잔고 부족!");
        else
            balance -= money;
    }

    public void showBalance() {
        System.out.println("계좌번호: "+accountNo);
        System.out.println("잔액 : " + balance);
    }
}
public class AccountManeger {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Boolean yes = true;
        Account account = new Account("110-464-167257");
        int num;
        while (yes) {
            System.out.println("--------------------------------");
            System.out.println("1.예금 | 2.출금 | 3.잔고 | 4.종료");
            System.out.println("--------------------------------");
            System.out.print("선택>");
            num = sc.nextInt();
            switch (num) {
                case 1 :
                    System.out.print("예금액>");
                    account.deposit(sc.nextInt());
                    break;
                case 2 :
                    System.out.print("출금액>");
                    account.withdraw(sc.nextInt());
                    break;
                case 3 :
                    account.showBalance();
                    break;
                case 4 :
                    System.out.println("프로그램 종료");
                    yes = false;
                    break;
                default :
                    System.out.println("입력 오류!!");
            }
        }
    }
}
