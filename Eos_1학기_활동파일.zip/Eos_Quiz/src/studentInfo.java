import java.util.InputMismatchException;
import java.util.Scanner;
class OutOfBound extends Exception {
    public OutOfBound() {
        super("1부터 3 사이의 값을 입력하시오.");
    }
}
public class studentInfo {

    public static void main(String[] args)  {


        Boolean keep = true;
        String name = "";
        int studentN = -1;
        while (keep) {
            Scanner num = new Scanner(System.in);
            System.out.println("-----------------");

            System.out.println("1. 이름, 학번 입력");
            System.out.println("2. 이름, 학번 출력");
            System.out.println("3. 프로그램 종료");
            System.out.println("-----------------");
            System.out.print("메뉴 입력 : ");
            try {
                int menu = num.nextInt();
                if (menu < 1 || menu > 3) {
                    throw new OutOfBound();
                }
                switch (menu) {
                    case 1:
                        name = setName();
                        studentN = setStudentN();
                        break;
                    case 2:
                        if (name == "" && studentN == -1){
                            System.out.println("학번, 이름이 입력되지 않았습니다.");
                            break;
                        }

                        System.out.println("이름 : " +name);
                        System.out.println("학번 : "+ studentN);
                        break;
                    case 3:
                        System.out.println("프로그램 종료");
                        keep = false;
                        break;
                    default:

                         }
            } catch (InputMismatchException e) {
                System.out.println("잘못된 타입을 입력받았습니다.");
            } catch (OutOfBound e) {
                System.out.println(e.getMessage());
            }

        }
    }
    public static String setName() {
        Scanner sc = new Scanner(System.in);
        System.out.print("이름 입력 : ");
        return sc.nextLine();
    }
    public static int setStudentN() {
        Scanner sc = new Scanner(System.in);
        System.out.print("학번 입력 : ");
        try {
            return sc.nextInt();
        }catch (InputMismatchException e) {
            System.out.println("정수를 입력하시오.");
            return setStudentN();

        }
    }
}