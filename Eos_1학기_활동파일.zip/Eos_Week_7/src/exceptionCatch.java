import java.util.Scanner;

public class exceptionCatch {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int index = sc.nextInt();
        int value = call(index);
        if(value != -1)
            System.out.println("call value : " +value);

    }

    public static int call(int index) {
        int[] arr = {1, 2, 3, 4, 5};
        try {
            return arr[index];
        } catch (IndexOutOfBoundsException e) {
            System.out.println(e.getMessage());
            return -1;
        } finally {
            System.out.println("에러 발생");
        }
    }
}
