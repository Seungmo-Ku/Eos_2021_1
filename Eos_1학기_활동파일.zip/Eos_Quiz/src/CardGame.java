import java.util.Scanner;

class Card {
    private int symbol;
    private int number;

    public Card(){}

    public Card(int symbol, int number) {
        this.symbol = symbol;
        this.number = number;
    }
    public Card(Card aCard) {
        this.symbol = aCard.symbol;
        this.number = aCard.number;
    }
    public boolean equals(Card anotherCard) {
        if (symbol == anotherCard.symbol && number == anotherCard.number)
            return true;
        else
            return false;
    }
    public String toString() {
        String msg = "";
        if (symbol == 0)
            msg += "Clubs";
        else if (symbol == 1)
            msg += "Diamonds";
        else if (symbol == 2)
            msg += "Hearts";
        else if (symbol == 3)
            msg += "Spades";
        return msg + ", " +number;
    }
    public static int compareCard(Card cardA, Card cardB) {
        if (cardA.number > cardB.number)
            return -1;
        else if (cardA.number < cardB.number)
            return 1;
        else
            return 0;
    }

    public int getSymbol() {
        return symbol;
    }

    public int getNumber() {
        return number;
    }

    public void setSymbol(int symbol) {
        this.symbol = symbol;
    }

    public void setNumber(int number) {
        this.number = number;
    }
}
class Participant {
    private String name;
    private Card card;
    private int point;

    public String getName() {
        return name;
    }

    public Card getCard() {
        return card;
    }

    public int getPoint() {
        return point;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCard(Card card) {
        this.card = card;
        this.card = new Card(card);
    }

    public void setPoint(int point) {
        this.point = point;
    }

    public Participant(){
         }

    public Participant(String name) {
        this.name = name;
        this.card = new Card();
        card.setSymbol((int)(Math.random()*3));
        card.setNumber((int)(Math.random()*12+1));
        point = 0;

    }
    public void addPoint(int point) {
        this.point += point;
    }
    public void changeCard() {
        card.setSymbol((int)(Math.random()*3));
        card.setNumber((int)(Math.random()*12+1));
    }
    public String toString() {
        String msg = "";
        msg += name + " has " + card.toString() + "(point:"+point+")";
        return msg;
    }
}
public class CardGame {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Player Name : ");
        String name = sc.next();
        Participant participant = new Participant(name);
        Participant dealer = new Participant("Dealer");
        System.out.println("----------------------");
        System.out.println(dealer.toString());
        System.out.println(participant.toString());
        if(Card.compareCard(participant.getCard(), dealer.getCard()) == -1) {
            participant.addPoint(1);
        }
        System.out.println("----------------------");
        participant.setCard(dealer.getCard());
        dealer.changeCard();

        System.out.println(dealer.toString());
        System.out.println(participant.toString());
        if(Card.compareCard(participant.getCard(), dealer.getCard()) == -1) {
            participant.addPoint(1);
        }
        System.out.println("----------------------");
        participant.setCard(dealer.getCard());
        dealer.changeCard();

        System.out.println(dealer.toString());
        System.out.println(participant.toString());
        if(Card.compareCard(participant.getCard(), dealer.getCard()) == -1) {

            participant.addPoint(1);
        }
        System.out.println("----------------------");
        participant.setCard(dealer.getCard());
        dealer.changeCard();

        System.out.println(participant.getName()+", "+participant.getPoint()+" points");

    }
}
