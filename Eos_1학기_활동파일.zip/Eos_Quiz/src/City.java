public class City {
    private String name;
    private int locationX, locationY;
    City(String name, int locationX, int locationY) {
        this.name = name;
        this.locationX = locationX;
        this.locationY = locationY;
    }
    City(String name) {
        this.name = name;
        this.locationX = (int)(Math.random()*361);
        this.locationY = (int)(Math.random()*361);
    }

    public String getName() {
        return name;
    }

    public int getLocationX() {
        return locationX;
    }

    public int getLocationY() {
        return locationY;
    }
    Boolean equals(City city) {
        if (name == city.getName() && locationX == city.getLocationX() && locationY == city.getLocationY())
            return true;
        else
            return false;
    }
    @Override
    public String toString () {
        return name + ", " + locationX + ", " + locationY;
    }
    static double distance (City city1, City city2) {
        return Math.sqrt(Math.pow(city1.getLocationX() - city2.getLocationX(), 2) + Math.pow(city1.getLocationY() - city2.getLocationY(), 2));
    }
}
