import java.util.Scanner;

public class week2 {
    public static double getTotal (int money, int year) {
        double sum = 0;
        sum = money * (1 + 0.045 * year);
        return sum;
    }

    public static void main(String[] args) {
        System.out.println(getTotal (10000, 4));

        Scanner helper = new Scanner(System.in);

        int studentNum = helper.nextInt();

        if (studentNum == 21)
            System.out.println("새내기");
        else System.out.println("헌내기");
    return;
    }
}
