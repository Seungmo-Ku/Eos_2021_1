import java.util.Scanner;

public class starshopping_2 {
    public static void main(String[] args) {
        int line, a, b;

        Scanner sc = new Scanner(System.in);

        line = sc.nextInt ();
        //line x line
        if (line % 2 == 0) { //짝수


        }else { //홀수
            for (a = 1; a <= line; a ++) {
                if (a == 1 || a == line) {
                    for (b = 1; b <= (line / 2); b ++)
                        System.out.print(" ");
                    System.out.print("*");
                    System.out.println();
                }
                else if (a <= line / 2) {
                    for (b = 1; b <= 4-a; b ++)
                        System.out.print(" ");
                    System.out.print("*");
                    for (b = 1; b <= (a-1)*2 - 1; b ++)
                        System.out.print(" ");
                    System.out.print("*");
                    System.out.println();
                }
                else if (a >= line / 2) {
                    for (b = 1; b <= 4-a; b ++)
                        System.out.print(" ");
                    System.out.print("*");
                    for (b = 1; b <= (a-1)*2 - 1; b ++)
                        System.out.print(" ");
                    System.out.print("*");
                    System.out.println();
                }else {
                    System.out.print("*");
                    for (b = 1; b <= line - 2; b ++)
                        System.out.print(" ");
                    System.out.print("*");
                    System.out.println();
                }
            }
        }
    }
}
